

<?php $__env->startSection('content'); ?>
<div class="container py-5">
    <div class="row">
        <!-- Sol Taraf - Profil Kartı -->
        <div class="col-md-4">
            <div class="card shadow-sm">
                <div class="card-body text-center">
                    <div class="position-relative d-inline-block mb-3">
                        <img src="<?php echo e($user->profile_photo ? asset('storage/profiles/' . $user->profile_photo) : 'https://ui-avatars.com/api/?name='.urlencode($user->name)); ?>" 
                             alt="Profil Fotoğrafı"
                             class="rounded-circle"
                             style="width: 120px; height: 120px; object-fit: cover;">
                        <button class="btn btn-sm btn-primary position-absolute bottom-0 end-0 rounded-circle"
                                style="width: 32px; height: 32px; padding: 0;"
                                data-bs-toggle="modal" 
                                data-bs-target="#editProfileModal">
                            <i class="fas fa-camera"></i>
                        </button>
                    </div>
                    
                    <h4 class="mb-1"><?php echo e($user->name); ?></h4>
                    <p class="text-muted mb-3"><?php echo e($user->email); ?></p>
                    
                    <div class="d-grid gap-2">
                        <button class="btn btn-outline-primary"
                                data-bs-toggle="modal" 
                                data-bs-target="#editProfileModal">
                            <i class="fas fa-edit me-2"></i>Profili Düzenle
                        </button>
                    </div>
                </div>
            </div>

            <!-- İstatistikler -->
            <div class="card shadow-sm mt-4">
                <div class="card-header bg-transparent">
                    <h5 class="card-title mb-0">
                        <i class="fas fa-chart-bar me-2 text-primary"></i>
                        İstatistikler
                    </h5>
                </div>
                <div class="card-body">
                    <div class="d-flex align-items-center mb-3">
                        <div class="flex-shrink-0">
                            <div class="rounded-circle bg-primary bg-opacity-10 p-3">
                                <i class="fas fa-book text-primary"></i>
                            </div>
                        </div>
                        <div class="flex-grow-1 ms-3">
                            <h6 class="mb-0">Toplam Ödünç Alma</h6>
                            <p class="mb-0 text-muted"><?php echo e($user->borrowings()->count()); ?> kitap</p>
                        </div>
                    </div>
                    
                    <div class="d-flex align-items-center mb-3">
                        <div class="flex-shrink-0">
                            <div class="rounded-circle bg-warning bg-opacity-10 p-3">
                                <i class="fas fa-clock text-warning"></i>
                            </div>
                        </div>
                        <div class="flex-grow-1 ms-3">
                            <h6 class="mb-0">Aktif Ödünç</h6>
                            <p class="mb-0 text-muted"><?php echo e($activeBorrowings->count()); ?> kitap</p>
                        </div>
                    </div>
                    
                    <div class="d-flex align-items-center">
                        <div class="flex-shrink-0">
                            <div class="rounded-circle bg-danger bg-opacity-10 p-3">
                                <i class="fas fa-money-bill text-danger"></i>
                            </div>
                        </div>
                        <div class="flex-grow-1 ms-3">
                            <h6 class="mb-0">Toplam Ceza</h6>
                            <p class="mb-0 text-muted"><?php echo e(number_format($totalFines, 2)); ?> ₺</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Sağ Taraf -->
        <div class="col-md-8">
            <!-- Aktif Ödünç Alınanlar -->
            <div class="card shadow-sm">
                <div class="card-header bg-transparent">
                    <h5 class="card-title mb-0">
                        <i class="fas fa-book-reader me-2 text-primary"></i>
                        Aktif Ödünç Aldığım Kitaplar
                    </h5>
                </div>
                <div class="card-body p-0">
                    <?php $__empty_1 = true; $__currentLoopData = $activeBorrowings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $borrowing): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="d-flex align-items-center p-3 border-bottom">
                            <div class="flex-shrink-0">
                                <div class="rounded bg-primary bg-opacity-10 p-3">
                                    <i class="fas fa-book fa-lg text-primary"></i>
                                </div>
                            </div>
                            <div class="flex-grow-1 ms-3">
                                <h6 class="mb-1"><?php echo e($borrowing->book->title); ?></h6>
                                <p class="text-muted small mb-0">
                                    <i class="fas fa-calendar-alt me-1"></i>
                                    Alınma: <?php echo e($borrowing->borrow_date->format('d.m.Y')); ?>

                                    <span class="mx-2">•</span>
                                    <i class="fas fa-calendar-check me-1"></i>
                                    İade: <?php echo e($borrowing->due_date->format('d.m.Y')); ?>

                                </p>
                            </div>
                            <div class="ms-auto d-flex align-items-center">
                                <?php if($borrowing->isOverdue()): ?>
                                    <span class="badge bg-danger me-2">
                                        <i class="fas fa-exclamation-circle me-1"></i>
                                        Gecikmiş
                                    </span>
                                <?php else: ?>
                                    <span class="badge bg-success me-2">
                                        <i class="fas fa-check-circle me-1"></i>
                                        Aktif
                                    </span>
                                <?php endif; ?>
                                
                                <form action="<?php echo e(route('profile.return-book', $borrowing)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="btn btn-outline-primary btn-sm">
                                        <i class="fas fa-undo-alt"></i>
                                        İade Et
                                    </button>
                                </form>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="text-center py-5">
                            <img src="https://cdn-icons-png.flaticon.com/512/2702/2702162.png" 
                                 alt="Boş Liste" 
                                 style="width: 120px; height: 120px; opacity: 0.5;">
                            <p class="text-muted mt-3">Aktif ödünç aldığınız kitap bulunmamaktadır.</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Geçmiş İşlemler -->
            <div class="card shadow-sm mt-4">
                <div class="card-header bg-transparent">
                    <h5 class="card-title mb-0">
                        <i class="fas fa-history me-2 text-primary"></i>
                        Geçmiş İşlemler
                    </h5>
                </div>
                <div class="card-body p-0">
                    <?php $__empty_1 = true; $__currentLoopData = $borrowingHistory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $borrowing): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="d-flex align-items-center p-3 border-bottom">
                            <div class="flex-shrink-0">
                                <div class="rounded bg-secondary bg-opacity-10 p-3">
                                    <i class="fas fa-history fa-lg text-secondary"></i>
                                </div>
                            </div>
                            <div class="flex-grow-1 ms-3">
                                <h6 class="mb-1"><?php echo e($borrowing->book->title); ?></h6>
                                <p class="text-muted small mb-0">
                                    <i class="fas fa-check-circle me-1"></i>
                                    İade Edildi: <?php echo e($borrowing->returned_at->format('d.m.Y')); ?>

                                    <?php if($borrowing->fine_amount > 0): ?>
                                        <span class="mx-2">•</span>
                                        <i class="fas fa-money-bill me-1"></i>
                                        Ceza: <?php echo e(number_format($borrowing->fine_amount, 2)); ?> ₺
                                    <?php endif; ?>
                                </p>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="text-center py-5">
                            <img src="https://cdn-icons-png.flaticon.com/512/1380/1380641.png" 
                                 alt="Boş Geçmiş" 
                                 style="width: 120px; height: 120px; opacity: 0.5;">
                            <p class="text-muted mt-3">Henüz iade edilmiş kitabınız bulunmamaktadır.</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Profil Düzenleme Modal -->
<div class="modal fade" id="editProfileModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">
                    <i class="fas fa-user-edit me-2"></i>
                    Profili Düzenle
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form action="<?php echo e(route('profile.update')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="modal-body">
                    <?php if(session('success')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('success')); ?>

                        </div>
                    <?php endif; ?>
                    
                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul class="mb-0">
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>

                    <div class="mb-3">
                        <label class="form-label">
                            <i class="fas fa-user me-1"></i>
                            Ad Soyad
                        </label>
                        <input type="text" 
                               class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                               name="name" 
                               value="<?php echo e(old('name', $user->name)); ?>" 
                               required>
                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">
                            <i class="fas fa-envelope me-1"></i>
                            E-posta
                        </label>
                        <input type="email" 
                               class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                               name="email" 
                               value="<?php echo e(old('email', $user->email)); ?>" 
                               required>
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">
                            <i class="fas fa-camera me-1"></i>
                            Profil Fotoğrafı
                        </label>
                        <input type="file" 
                               class="form-control <?php $__errorArgs = ['profile_photo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                               name="profile_photo" 
                               accept="image/jpeg,image/png,image/jpg,image/gif">
                        <div class="form-text">PNG, JPG veya JPEG (Max. 2MB)</div>
                        <?php $__errorArgs = ['profile_photo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback d-block"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        
                        <?php if($user->profile_photo): ?>
                            <div class="mt-2">
                                <p class="mb-1">Mevcut fotoğraf:</p>
                                <img src="<?php echo e(asset('storage/profiles/' . $user->profile_photo)); ?>" 
                                     alt="Mevcut profil fotoğrafı" 
                                     class="img-thumbnail" 
                                     style="max-height: 100px;">
                            </div>
                        <?php endif; ?>
                    </div>
                    
                    <hr>
                    
                    <div class="mb-3">
                        <label class="form-label">
                            <i class="fas fa-lock me-1"></i>
                            Mevcut Şifre
                        </label>
                        <input type="password" 
                               class="form-control <?php $__errorArgs = ['current_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                               name="current_password">
                        <?php $__errorArgs = ['current_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">
                            <i class="fas fa-key me-1"></i>
                            Yeni Şifre
                        </label>
                        <input type="password" 
                               class="form-control <?php $__errorArgs = ['new_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                               name="new_password">
                        <?php $__errorArgs = ['new_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">
                            <i class="fas fa-check-double me-1"></i>
                            Yeni Şifre Tekrar
                        </label>
                        <input type="password" 
                               class="form-control <?php $__errorArgs = ['new_password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                               name="new_password_confirmation">
                        <?php $__errorArgs = ['new_password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                        <i class="fas fa-times me-1"></i>
                        İptal
                    </button>
                    <button type="submit" class="btn btn-primary" id="saveProfileBtn">
                        <i class="fas fa-save me-1"></i>
                        Kaydet
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Form gönderildiğinde butonu devre dışı bırak
        const form = document.querySelector('form[action="<?php echo e(route('profile.update')); ?>"]');
        const saveBtn = document.getElementById('saveProfileBtn');
        
        if (form && saveBtn) {
            form.addEventListener('submit', function() {
                saveBtn.disabled = true;
                saveBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-1"></i> Kaydediliyor...';
            });
        }
        
        // Hata varsa modalı otomatik olarak aç
        <?php if($errors->any()): ?>
            const editModal = new bootstrap.Modal(document.getElementById('editProfileModal'));
            editModal.show();
        <?php endif; ?>
    });
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\irmak\Desktop\KutuphaneOtomasyon\resources\views/profile/index.blade.php ENDPATH**/ ?>