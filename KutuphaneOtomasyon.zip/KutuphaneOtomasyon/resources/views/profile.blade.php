@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <!-- Sol Taraf - Profil Kartı -->
        <div class="col-md-4">
            <div class="card">
                <div class="card-body text-center">
                    <img src="{{ Auth::user()->profile_photo ?? 'https://ui-avatars.com/api/?name='.urlencode(Auth::user()->name) }}" 
                         alt="Profil Fotoğrafı"
                         class="rounded-circle mb-3"
                         style="width: 150px; height: 150px; object-fit: cover;">
                    
                    <h4 class="card-title">{{ Auth::user()->name }}</h4>
                    <p class="text-muted">{{ Auth::user()->email }}</p>
                    
                    <div class="mt-3">
                        <button class="btn btn-outline-primary btn-sm" data-bs-toggle="modal" data-bs-target="#editProfileModal">
                            <i class="fas fa-edit"></i> Profili Düzenle
                        </button>
                    </div>
                </div>
            </div>

            <!-- İstatistikler -->
            <div class="card mt-4">
                <div class="card-body">
                    <h5 class="card-title mb-4">İstatistikler</h5>
                    
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <div class="text-muted">Ödünç Alınan Kitaplar</div>
                        <div class="badge bg-primary">{{ Auth::user()->borrowings()->count() }}</div>
                    </div>
                    
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <div class="text-muted">Aktif Ödünç</div>
                        <div class="badge bg-warning">{{ Auth::user()->activeBorrowings()->count() }}</div>
                    </div>
                    
                    <div class="d-flex justify-content-between align-items-center">
                        <div class="text-muted">Toplam Ceza</div>
                        <div class="badge bg-danger">{{ number_format(Auth::user()->borrowings()->sum('fine_amount'), 2) }} ₺</div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Sağ Taraf - Aktif Ödünç Alınanlar -->
        <div class="col-md-8">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title mb-4">Aktif Ödünç Aldığım Kitaplar</h5>
                    
                    @foreach(Auth::user()->activeBorrowings as $borrowing)
                    <div class="d-flex align-items-center p-3 border-bottom">
                        <div class="flex-shrink-0">
                            <i class="fas fa-book fa-2x text-primary"></i>
                        </div>
                        <div class="flex-grow-1 ms-3">
                            <h6 class="mb-1">{{ $borrowing->book->title }}</h6>
                            <p class="text-muted small mb-0">
                                Alınma Tarihi: {{ $borrowing->borrow_date->format('d.m.Y') }}
                                <br>
                                İade Tarihi: {{ $borrowing->return_date->format('d.m.Y') }}
                            </p>
                        </div>
                        <div class="ms-auto">
                            @if($borrowing->isOverdue())
                                <span class="badge bg-danger">Gecikmiş</span>
                            @else
                                <span class="badge bg-success">Aktif</span>
                            @endif
                        </div>
                    </div>
                    @endforeach

                    @if(Auth::user()->activeBorrowings->isEmpty())
                        <div class="text-center text-muted py-3">
                            <i class="fas fa-info-circle mb-2"></i>
                            <p class="mb-0">Aktif ödünç aldığınız kitap bulunmamaktadır.</p>
                        </div>
                    @endif
                </div>
            </div>

            <!-- Geçmiş İşlemler -->
            <div class="card mt-4">
                <div class="card-body">
                    <h5 class="card-title mb-4">Son İşlemler</h5>
                    
                    @foreach(Auth::user()->borrowings()->where('is_returned', true)->latest()->take(5)->get() as $borrowing)
                    <div class="d-flex align-items-center p-3 border-bottom">
                        <div class="flex-shrink-0">
                            <i class="fas fa-history fa-2x text-secondary"></i>
                        </div>
                        <div class="flex-grow-1 ms-3">
                            <h6 class="mb-1">{{ $borrowing->book->title }}</h6>
                            <p class="text-muted small mb-0">
                                İade Edildi: {{ $borrowing->updated_at->format('d.m.Y') }}
                            </p>
                        </div>
                    </div>
                    @endforeach

                    @if(Auth::user()->borrowings()->where('is_returned', true)->count() == 0)
                        <div class="text-center text-muted py-3">
                            <i class="fas fa-info-circle mb-2"></i>
                            <p class="mb-0">Henüz iade edilmiş kitabınız bulunmamaktadır.</p>
                        </div>
                    @endif
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Profil Düzenleme Modal -->
<div class="modal fade" id="editProfileModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Profili Düzenle</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form action="{{ route('profile.update') }}" method="POST" enctype="multipart/form-data">
                @csrf
                @method('PUT')
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">Ad Soyad</label>
                        <input type="text" class="form-control" name="name" value="{{ Auth::user()->name }}" required>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">E-posta</label>
                        <input type="email" class="form-control" name="email" value="{{ Auth::user()->email }}" required>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Profil Fotoğrafı</label>
                        <input type="file" class="form-control" name="profile_photo">
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Yeni Şifre (İsteğe bağlı)</label>
                        <input type="password" class="form-control" name="password">
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Yeni Şifre Tekrar</label>
                        <input type="password" class="form-control" name="password_confirmation">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">İptal</button>
                    <button type="submit" class="btn btn-primary">Kaydet</button>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection 