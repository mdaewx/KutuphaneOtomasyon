

<?php $__env->startSection('title', 'Kitap Yönetimi'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Kitap Yönetimi</h1>
        <a href="<?php echo e(route('admin.books.create')); ?>" class="btn btn-sm btn-primary shadow-sm">
            <i class="fas fa-plus fa-sm text-white-50"></i> Yeni Kitap Ekle
        </a>
    </div>

    <!-- Books DataTable -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Kitap Listesi</h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="booksTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th width="50">ID</th>
                            <th width="80">Kapak</th>
                            <th>Kitap Adı</th>
                            <th>Yazar</th>
                            <th>Kategori</th>
                            <th>Raf No</th>
                            <th>ISBN</th>
                            <th>Miktar</th>
                            <th width="150">İşlemler</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($book->id); ?></td>
                            <td class="text-center">
                                <?php if($book->cover_image): ?>
                                    <img src="<?php echo e(asset('storage/books/' . $book->cover_image)); ?>" 
                                         alt="<?php echo e($book->title); ?>" class="img-thumbnail" style="max-height: 50px;">
                                <?php else: ?>
                                    <i class="fas fa-book fa-2x text-gray-300"></i>
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($book->title); ?></td>
                            <td><?php echo e($book->author); ?></td>
                            <td><?php echo e($book->category->name ?? 'Kategorisiz'); ?></td>
                            <td><?php echo e($book->shelf_number); ?></td>
                            <td><?php echo e($book->isbn); ?></td>
                            <td>
                                <span class="badge bg-<?php echo e($book->available_quantity > 0 ? 'success' : 'danger'); ?>">
                                    <?php echo e($book->available_quantity); ?>/<?php echo e($book->quantity); ?>

                                </span>
                            </td>
                            <td>
                                <div class="btn-group" role="group">
                                    <a href="<?php echo e(route('admin.books.show', $book->id)); ?>" class="btn btn-info btn-sm">
                                        <i class="fas fa-eye"></i>
                                    </a>
                                    <a href="<?php echo e(route('admin.books.edit', $book->id)); ?>" class="btn btn-primary btn-sm">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <button type="button" class="btn btn-danger btn-sm delete-book" data-bs-toggle="modal" data-bs-target="#deleteModal" data-book-id="<?php echo e($book->id); ?>" data-book-title="<?php echo e($book->title); ?>">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Global Delete Modal -->
<div class="modal fade" id="deleteModal" tabindex="-1" aria-labelledby="deleteModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="deleteModalLabel">Kitap Sil</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <p id="delete-message">Bu kitabı silmek istediğinize emin misiniz?</p>
                <p class="text-danger">Bu işlem geri alınamaz!</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">İptal</button>
                <form id="delete-form" action="" method="POST" style="display: inline-block;">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-danger">Evet, Sil</button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    $(document).ready(function() {
        $('#booksTable').DataTable({
            language: {
                url: '//cdn.datatables.net/plug-ins/1.10.25/i18n/Turkish.json'
            },
            order: [[0, 'desc']],
            columnDefs: [
                { orderable: false, targets: [1, 8] }
            ]
        });
        
        // Kitap silme modalını yapılandır
        $('.delete-book').on('click', function() {
            var bookId = $(this).data('book-id');
            var bookTitle = $(this).data('book-title');
            
            // Modal içeriğini güncelle
            $('#delete-message').text(bookTitle + ' adlı kitabı silmek istediğinize emin misiniz?');
            
            // Form action URL'sini ayarla
            var deleteUrl = "<?php echo e(route('admin.books.destroy', ':id')); ?>";
            deleteUrl = deleteUrl.replace(':id', bookId);
            $('#delete-form').attr('action', deleteUrl);
        });
    });
</script>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\irmak\Desktop\KutuphaneOtomasyon\resources\views/admin/books/index.blade.php ENDPATH**/ ?>