<?php

namespace App\Http\Controllers;

use App\Models\Book;
use App\Models\Category;
use App\Models\Publisher;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;

class AdminBookController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $books = Book::with('category')->get();
        return view('admin.books.index', compact('books'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $categories = Category::all();
        return view('admin.books.create', compact('categories'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'title' => 'required|string|max:255',
            'author' => 'required|string|max:255',
            'category_id' => 'required|exists:categories,id',
            'description' => 'required|string',
            'publisher' => 'required|string|max:255',
            'language' => 'nullable|string|max:50',
            'publication_year' => 'required|integer|min:1000|max:' . date('Y'),
            'isbn' => 'required|string|max:20|unique:books,isbn',
            'page_count' => 'required|integer|min:1',
            'shelf_number' => 'required|string|max:20',
            'quantity' => 'required|integer|min:1',
            'cover_image' => 'nullable|image|max:2048',
        ]);

        $book = new Book();
        $book->title = $validated['title'];
        $book->slug = Str::slug($validated['title']);
        $book->author = $validated['author'];
        $book->category_id = $validated['category_id'];
        $book->description = $validated['description'];
        
        // Publisher'ı ilişki üzerinden ekleyelim
        // Önce mevcut publisher'ı arayalım veya yenisini oluşturalım
        $publisher = Publisher::firstOrCreate(['name' => $validated['publisher']]);
        $book->publisher_id = $publisher->id;
        
        $book->language = $validated['language'] ?? null;
        $book->publication_year = $validated['publication_year'];
        $book->isbn = $validated['isbn'];
        $book->page_count = $validated['page_count'];
        $book->shelf_number = $validated['shelf_number'];
        $book->quantity = $validated['quantity'];
        $book->available_quantity = $validated['quantity'];

        if ($request->hasFile('cover_image')) {
            $path = $request->file('cover_image')->store('books', 'public');
            $book->cover_image = basename($path);
        }

        $book->save();

        return redirect()->route('admin.books.index')
            ->with('success', 'Kitap başarıyla eklendi.');
    }

    /**
     * Display the specified resource.
     */
    public function show(Book $book)
    {
        $book->load(['category', 'activeBorrowings.user']);
        return view('admin.books.show', compact('book'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Book $book)
    {
        $categories = Category::all();
        return view('admin.books.edit', compact('book', 'categories'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Book $book)
    {
        $validated = $request->validate([
            'title' => 'required|string|max:255',
            'author' => 'required|string|max:255',
            'category_id' => 'required|exists:categories,id',
            'description' => 'required|string',
            'publisher' => 'required|string|max:255',
            'language' => 'nullable|string|max:50',
            'publication_year' => 'required|integer|min:1000|max:' . date('Y'),
            'isbn' => 'required|string|max:20|unique:books,isbn,' . $book->id,
            'page_count' => 'required|integer|min:1',
            'shelf_number' => 'required|string|max:20',
            'quantity' => 'required|integer|min:1',
            'cover_image' => 'nullable|image|max:2048',
        ]);

        $book->title = $validated['title'];
        $book->slug = Str::slug($validated['title']);
        $book->author = $validated['author'];
        $book->category_id = $validated['category_id'];
        $book->description = $validated['description'];
        
        // Publisher'ı ilişki üzerinden ekleyelim
        // Önce mevcut publisher'ı arayalım veya yenisini oluşturalım
        $publisher = Publisher::firstOrCreate(['name' => $validated['publisher']]);
        $book->publisher_id = $publisher->id;
        
        $book->language = $validated['language'] ?? null;
        $book->publication_year = $validated['publication_year'];
        $book->isbn = $validated['isbn'];
        $book->page_count = $validated['page_count'];
        $book->shelf_number = $validated['shelf_number'];
        
        // Ödünç verilmiş kitaplar için miktar kontrolü
        $borrowedCount = $book->quantity - $book->available_quantity;
        if ($validated['quantity'] < $borrowedCount) {
            return back()->withErrors(['quantity' => 'Kitap miktarı, ödünç verilmiş kitap sayısından az olamaz.'])->withInput();
        }
        
        $book->available_quantity = $book->available_quantity + ($validated['quantity'] - $book->quantity);
        $book->quantity = $validated['quantity'];

        if ($request->hasFile('cover_image')) {
            // Eski dosyayı silelim
            if ($book->cover_image) {
                Storage::disk('public')->delete('books/' . $book->cover_image);
            }
            
            $path = $request->file('cover_image')->store('books', 'public');
            $book->cover_image = basename($path);
        }

        $book->save();

        return redirect()->route('admin.books.index')
            ->with('success', 'Kitap başarıyla güncellendi.');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Book $book)
    {
        // Ödünç verilmiş kitapları kontrol et
        if ($book->borrowings()->whereNull('returned_at')->count() > 0) {
            return redirect()->route('admin.books.index')
                ->with('error', 'Bu kitap ödünç verilmiş durumda olduğu için silinemez.');
        }

        // Kitap kapak resmini sil
        if ($book->cover_image) {
            Storage::disk('public')->delete('books/' . $book->cover_image);
        }

        $book->delete();

        return redirect()->route('admin.books.index')
            ->with('success', 'Kitap başarıyla silindi.');
    }

    /**
     * Upload a cover image for a book.
     */
    public function uploadCover(Request $request, Book $book)
    {
        $request->validate([
            'cover_image' => 'required|image|max:2048',
        ]);

        // Eski kapak resmi varsa sil
        if ($book->cover_image) {
            Storage::disk('public')->delete('books/' . $book->cover_image);
        }

        // Yeni kapak resmini yükle
        $path = $request->file('cover_image')->store('books', 'public');
        $book->cover_image = basename($path);
        $book->save();

        return redirect()->route('admin.books.edit', $book)
            ->with('success', 'Kitap kapağı başarıyla güncellendi.');
    }
} 