<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\LibraryController;
use App\Http\Controllers\BookController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\AdminUserController;
use App\Http\Controllers\AdminBookController;
use App\Http\Controllers\AdminBorrowingController;
use App\Http\Controllers\AdminCategoryController;
use App\Http\Controllers\AdminReportController;
use App\Http\Controllers\AdminSettingController;
use App\Http\Controllers\AdminProfileController;
use App\Http\Controllers\TestAdminController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

// Ana sayfa ve kitaplar
Route::get('/', [LibraryController::class, 'index'])->name('home');
Route::get('/books/search', [BookController::class, 'search'])->name('books.search');
Route::get('/books', [BookController::class, 'index'])->name('books.index');
Route::get('/books/{book}', [BookController::class, 'show'])->name('books.show');

// Ödünç alma işlemi için route
Route::post('/borrowings', [BookController::class, 'borrow'])->name('borrowings.store')->middleware('auth');

// Redirect from /dashboard to /admin/dashboard
Route::redirect('/dashboard', '/admin/dashboard');

// Kullanıcı profili
Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'index'])->name('profile');
    Route::put('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::post('/profile/return-book/{borrowing}', [ProfileController::class, 'returnBook'])->name('profile.return-book');
});

// Admin Panel
Route::middleware(['auth', 'admin'])->prefix('admin')->name('admin.')->group(function () {
    // Dashboard
    Route::get('/{path?}', [AdminController::class, 'dashboard'])
        ->name('dashboard')
        ->where('path', '^$|^dashboard$'); // Boş string veya "dashboard" kabul eder
    
    // Borrowings
    Route::get('/borrowings', [AdminBorrowingController::class, 'index'])->name('borrowings.index');
    Route::get('/borrowings/create', [AdminBorrowingController::class, 'create'])->name('borrowings.create');
    Route::post('/borrowings', [AdminBorrowingController::class, 'store'])->name('borrowings.store');
    Route::get('/borrowings/{borrowing}', [AdminBorrowingController::class, 'show'])->name('borrowings.show');
    Route::put('/borrowings/{borrowing}/return', [AdminBorrowingController::class, 'returnBook'])->name('borrowings.return');
    Route::put('/borrowings/{borrowing}/update-status', [AdminBorrowingController::class, 'updateStatus'])->name('borrowings.update-status');
    Route::delete('/borrowings/{borrowing}', [AdminBorrowingController::class, 'destroy'])->name('borrowings.destroy');
    
    // Admin Profile Management
    Route::resource('profiles', AdminProfileController::class);
    
    // Kullanıcı Yönetimi
    Route::resource('users', AdminUserController::class);
    
    // Kitap Yönetimi
    Route::resource('books', AdminBookController::class);
    Route::post('/books/{book}/upload-cover', [AdminBookController::class, 'uploadCover'])->name('books.upload-cover');
    
    // Kategori Yönetimi
    Route::resource('categories', AdminCategoryController::class);
    
    // Raporlar
    Route::get('reports', [AdminReportController::class, 'index'])->name('reports.index');
    Route::get('reports/popular-books', [AdminReportController::class, 'popularBooks'])->name('reports.popular-books');
    Route::get('reports/active-users', [AdminReportController::class, 'activeUsers'])->name('reports.active-users');
    Route::get('reports/overdue', [AdminReportController::class, 'overdue'])->name('reports.overdue');
    Route::get('reports/monthly-stats', [AdminReportController::class, 'monthlyStats'])->name('reports.monthly-stats');
    Route::get('reports/categories', [AdminReportController::class, 'categories'])->name('reports.categories');
    
    // Ayarlar
    Route::get('settings', [AdminSettingController::class, 'index'])->name('settings.index');
    Route::put('settings', [AdminSettingController::class, 'update'])->name('settings.update');
    Route::post('settings/clear-cache', [AdminSettingController::class, 'clearCache'])->name('settings.clear-cache');
});

// Test route for admin dashboard
Route::get('/test-dashboard', [TestAdminController::class, 'dashboard'])
    ->middleware(['auth'])
    ->name('test.dashboard');

require __DIR__.'/auth.php';
