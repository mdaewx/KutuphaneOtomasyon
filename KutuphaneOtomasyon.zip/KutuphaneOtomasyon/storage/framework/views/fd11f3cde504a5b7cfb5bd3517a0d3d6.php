

<?php $__env->startSection('title', 'Sistem Ayarları'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <h1 class="h3 mb-4 text-gray-800">Sistem Ayarları</h1>

    <?php if(session('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>
    <?php endif; ?>

    <div class="row">
        <div class="col-lg-8">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Genel Ayarlar</h6>
                </div>
                <div class="card-body">
                    <form action="<?php echo e(route('admin.settings.update')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>

                        <div class="form-group row mb-3">
                            <label for="site_title" class="col-sm-3 col-form-label">Site Başlığı</label>
                            <div class="col-sm-9">
                                <input type="text" class="form-control" id="site_title" name="site_title" value="<?php echo e($settings['site_title'] ?? 'Kütüphane Otomasyonu'); ?>">
                                <?php $__errorArgs = ['site_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="text-danger"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="form-group row mb-3">
                            <label for="welcome_message" class="col-sm-3 col-form-label">Karşılama Mesajı</label>
                            <div class="col-sm-9">
                                <textarea class="form-control" id="welcome_message" name="welcome_message" rows="3"><?php echo e($settings['welcome_message'] ?? 'Kütüphane Otomasyonu Sistemine Hoş Geldiniz'); ?></textarea>
                                <?php $__errorArgs = ['welcome_message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="text-danger"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="form-group row mb-3">
                            <label for="max_books_per_user" class="col-sm-3 col-form-label">Kullanıcı Başına Maksimum Kitap</label>
                            <div class="col-sm-9">
                                <input type="number" class="form-control" id="max_books_per_user" name="max_books_per_user" min="1" max="20" value="<?php echo e($settings['max_books_per_user'] ?? 5); ?>">
                                <?php $__errorArgs = ['max_books_per_user'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="text-danger"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="form-group row mb-3">
                            <label for="loan_period_days" class="col-sm-3 col-form-label">Ödünç Verme Süresi (Gün)</label>
                            <div class="col-sm-9">
                                <input type="number" class="form-control" id="loan_period_days" name="loan_period_days" min="1" max="60" value="<?php echo e($settings['loan_period_days'] ?? 14); ?>">
                                <?php $__errorArgs = ['loan_period_days'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="text-danger"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="form-group row mb-3">
                            <label for="overdue_fine_per_day" class="col-sm-3 col-form-label">Gecikme Cezası (₺/Gün)</label>
                            <div class="col-sm-9">
                                <input type="number" step="0.01" class="form-control" id="overdue_fine_per_day" name="overdue_fine_per_day" min="0" max="10" value="<?php echo e($settings['overdue_fine_per_day'] ?? 1.00); ?>">
                                <?php $__errorArgs = ['overdue_fine_per_day'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="text-danger"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="form-group row mb-3">
                            <label class="col-sm-3 col-form-label">E-posta Bildirimleri</label>
                            <div class="col-sm-9">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" id="email_notifications" name="email_notifications" value="1" <?php echo e(($settings['email_notifications'] ?? false) ? 'checked' : ''); ?>>
                                    <label class="form-check-label" for="email_notifications">
                                        E-posta bildirimlerini etkinleştir
                                    </label>
                                </div>
                                <?php $__errorArgs = ['email_notifications'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="text-danger"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="form-group row mb-3">
                            <label class="col-sm-3 col-form-label">Bakım Modu</label>
                            <div class="col-sm-9">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" id="maintenance_mode" name="maintenance_mode" value="1" <?php echo e(($settings['maintenance_mode'] ?? false) ? 'checked' : ''); ?>>
                                    <label class="form-check-label" for="maintenance_mode">
                                        Bakım modunu etkinleştir
                                    </label>
                                </div>
                                <?php $__errorArgs = ['maintenance_mode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="text-danger"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="text-end">
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-save me-1"></i> Ayarları Kaydet
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <div class="col-lg-4">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Sistem İşlemleri</h6>
                </div>
                <div class="card-body">
                    <div class="mb-3">
                        <h5>Önbellek Yönetimi</h5>
                        <p class="text-muted small">Sistem performansını artırmak için önbelleğe alınan verileri temizleyebilirsiniz.</p>
                        <form action="<?php echo e(route('admin.settings.clear-cache')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="btn btn-warning">
                                <i class="fas fa-broom me-1"></i> Önbelleği Temizle
                            </button>
                        </form>
                    </div>

                    <div class="mb-3">
                        <h5>Sistem Bilgileri</h5>
                        <table class="table table-sm">
                            <tr>
                                <td>PHP Versiyonu</td>
                                <td><span class="badge bg-info"><?php echo e(phpversion()); ?></span></td>
                            </tr>
                            <tr>
                                <td>Laravel Versiyonu</td>
                                <td><span class="badge bg-info"><?php echo e(app()->version()); ?></span></td>
                            </tr>
                            <tr>
                                <td>Ortam</td>
                                <td><span class="badge bg-<?php echo e(app()->environment('production') ? 'success' : 'warning'); ?>"><?php echo e(app()->environment()); ?></span></td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\irmak\Desktop\KutuphaneOtomasyon\resources\views/admin/settings/index.blade.php ENDPATH**/ ?>