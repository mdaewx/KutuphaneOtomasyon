<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Book extends Model
{
    use HasFactory;

    protected $fillable = [
        'title',
        'slug',
        'author',
        'description',
        'category_id',
        'publisher_id',
        'language',
        'publication_year',
        'page_count',
        'isbn',
        'cover_image',
        'status',
        'quantity',
        'available_quantity',
        'shelf_number'
    ];

    // Ödünç verme işlemleri
    public function borrowings()
    {
        return $this->hasMany(Borrowing::class);
    }

    // Kitabın aktif ödünçleri
    public function activeBorrowings()
    {
        return $this->borrowings()->whereNull('returned_at');
    }

    // Kategori ilişkisi
    public function category()
    {
        return $this->belongsTo(Category::class);
    }

    // Yayıncı ilişkisi
    public function publisher()
    {
        return $this->belongsTo(Publisher::class);
    }

    // Yazarlar çoklu ilişkisi
    public function authors()
    {
        return $this->belongsToMany(Author::class);
    }

    // Stok bilgileri
    public function stock()
    {
        return $this->hasOne(Stock::class);
    }

    // Cezalar ilişkisi
    public function fines()
    {
        return $this->hasMany(Fine::class);
    }

    // Favori kitaplar ilişkisi
    public function favoritedBy()
    {
        return $this->belongsToMany(User::class, 'favorite_books');
    }

    // Önerilen kitaplar ilişkisi
    public function suggestedTo()
    {
        return $this->belongsToMany(User::class, 'suggested_books');
    }

    /**
     * Kitabın kullanılabilir olup olmadığını kontrol eder
     * 
     * @return bool
     */
    public function isAvailable()
    {
        // Veritabanında tutarlılık sağla - aktif ödünçleri yeniden hesapla
        $activeLoans = $this->activeBorrowings()->count();
        
        // Eğer available_quantity ve aktif ödünçler arasında tutarsızlık varsa, düzelt
        $expectedAvailable = max(0, $this->quantity - $activeLoans);
        
        // Tutarsızlık varsa düzelt
        if ($this->available_quantity != $expectedAvailable) {
            $this->available_quantity = $expectedAvailable;
            
            // Durum değişikliği
            if ($expectedAvailable <= 0) {
                $this->status = 'borrowed';
            } else {
                $this->status = 'available';
            }
            
            $this->save();
        }
        
        // Güncellenmiş durumu kontrol et
        return $this->available_quantity > 0 && $this->status !== 'borrowed';
    }
}
