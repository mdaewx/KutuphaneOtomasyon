@extends('layouts.admin')

@section('title', 'Yeni Kitap Ekle')

@section('content')
<div class="container-fluid">
    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Yeni Kitap Ekle</h1>
        <a href="{{ route('admin.books.index') }}" class="btn btn-sm btn-secondary shadow-sm">
            <i class="fas fa-arrow-left fa-sm text-white-50"></i> Kitap Listesine Dön
        </a>
    </div>

    <!-- Create Book Card -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Kitap Bilgileri</h6>
        </div>
        <div class="card-body">
            <form method="POST" action="{{ route('admin.books.store') }}" enctype="multipart/form-data">
                @csrf

                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="title">Kitap Adı <span class="text-danger">*</span></label>
                            <input type="text" class="form-control @error('title') is-invalid @enderror" 
                                id="title" name="title" value="{{ old('title') }}" required>
                            @error('title')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="author">Yazar <span class="text-danger">*</span></label>
                            <input type="text" class="form-control @error('author') is-invalid @enderror" 
                                id="author" name="author" value="{{ old('author') }}" required>
                            @error('author')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-3">
                        <div class="form-group">
                            <label for="category_id">Kategori <span class="text-danger">*</span></label>
                            <select class="form-control @error('category_id') is-invalid @enderror" 
                                id="category_id" name="category_id" required>
                                <option value="">-- Kategori Seçin --</option>
                                @foreach($categories as $category)
                                    <option value="{{ $category->id }}" {{ old('category_id') == $category->id ? 'selected' : '' }}>
                                        {{ $category->name }}
                                    </option>
                                @endforeach
                            </select>
                            @error('category_id')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="form-group">
                            <label for="publisher">Yayınevi <span class="text-danger">*</span></label>
                            <input type="text" class="form-control @error('publisher') is-invalid @enderror" 
                                id="publisher" name="publisher" value="{{ old('publisher') }}" required>
                            @error('publisher')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="form-group">
                            <label for="language">Kitap Dili</label>
                            <select class="form-control @error('language') is-invalid @enderror" 
                                id="language" name="language">
                                <option value="">-- Dil Seçin --</option>
                                <option value="Türkçe" {{ old('language') == 'Türkçe' ? 'selected' : '' }}>Türkçe</option>
                                <option value="İngilizce" {{ old('language') == 'İngilizce' ? 'selected' : '' }}>İngilizce</option>
                                <option value="Almanca" {{ old('language') == 'Almanca' ? 'selected' : '' }}>Almanca</option>
                                <option value="Fransızca" {{ old('language') == 'Fransızca' ? 'selected' : '' }}>Fransızca</option>
                                <option value="İspanyolca" {{ old('language') == 'İspanyolca' ? 'selected' : '' }}>İspanyolca</option>
                                <option value="İtalyanca" {{ old('language') == 'İtalyanca' ? 'selected' : '' }}>İtalyanca</option>
                                <option value="Rusça" {{ old('language') == 'Rusça' ? 'selected' : '' }}>Rusça</option>
                                <option value="Arapça" {{ old('language') == 'Arapça' ? 'selected' : '' }}>Arapça</option>
                                <option value="Çince" {{ old('language') == 'Çince' ? 'selected' : '' }}>Çince</option>
                                <option value="Japonca" {{ old('language') == 'Japonca' ? 'selected' : '' }}>Japonca</option>
                                <option value="Korece" {{ old('language') == 'Korece' ? 'selected' : '' }}>Korece</option>
                                <option value="Diğer" {{ old('language') == 'Diğer' ? 'selected' : '' }}>Diğer</option>
                            </select>
                            @error('language')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="form-group">
                            <label for="publication_year">Basım Yılı <span class="text-danger">*</span></label>
                            <input type="number" class="form-control @error('publication_year') is-invalid @enderror" 
                                id="publication_year" name="publication_year" 
                                value="{{ old('publication_year') }}" min="1000" max="{{ date('Y') }}" required>
                            @error('publication_year')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="isbn">ISBN <span class="text-danger">*</span></label>
                            <input type="text" class="form-control @error('isbn') is-invalid @enderror" 
                                id="isbn" name="isbn" value="{{ old('isbn') }}" required>
                            @error('isbn')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="page_count">Sayfa Sayısı <span class="text-danger">*</span></label>
                            <input type="number" class="form-control @error('page_count') is-invalid @enderror" 
                                id="page_count" name="page_count" value="{{ old('page_count') }}" min="1" required>
                            @error('page_count')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="shelf_number">Raf Numarası <span class="text-danger">*</span></label>
                            <input type="text" class="form-control @error('shelf_number') is-invalid @enderror" 
                                id="shelf_number" name="shelf_number" value="{{ old('shelf_number') }}" required>
                            @error('shelf_number')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="quantity">Miktar <span class="text-danger">*</span></label>
                            <input type="number" class="form-control @error('quantity') is-invalid @enderror" 
                                id="quantity" name="quantity" value="{{ old('quantity', 1) }}" min="1" required>
                            @error('quantity')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="cover_image">Kapak Resmi</label>
                            <div class="custom-file">
                                <input type="file" class="custom-file-input @error('cover_image') is-invalid @enderror" 
                                    id="cover_image" name="cover_image" accept="image/*">
                                <label class="custom-file-label" for="cover_image">Dosya seçin...</label>
                                @error('cover_image')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                        </div>
                    </div>
                </div>

                <div class="form-group">
                    <label for="description">Açıklama <span class="text-danger">*</span></label>
                    <textarea class="form-control @error('description') is-invalid @enderror" 
                        id="description" name="description" rows="5" required>{{ old('description') }}</textarea>
                    @error('description')
                        <div class="invalid-feedback">{{ $message }}</div>
                    @enderror
                </div>

                <div class="form-group mt-4">
                    <button type="submit" class="btn btn-primary">Kitap Ekle</button>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection

@section('scripts')
<script>
    // Dosya adını göster (Bootstrap 5 custom file input)
    document.querySelector('.custom-file-input').addEventListener('change', function(e) {
        var fileName = e.target.files[0].name;
        var nextSibling = e.target.nextElementSibling;
        nextSibling.innerText = fileName;
    });
</script>
@endsection 