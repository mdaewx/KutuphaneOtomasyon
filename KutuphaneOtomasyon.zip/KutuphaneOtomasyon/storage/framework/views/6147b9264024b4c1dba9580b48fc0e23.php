<?php $__env->startSection('title', 'Kullanıcılar'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Kullanıcı Yönetimi</h1>
        <a href="<?php echo e(route('admin.users.create')); ?>" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm">
            <i class="fas fa-user-plus fa-sm text-white-50"></i> Yeni Kullanıcı Ekle
        </a>
    </div>

    <!-- Search and Filter -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Kullanıcı Arama</h6>
        </div>
        <div class="card-body">
            <form action="<?php echo e(route('admin.users.index')); ?>" method="GET" class="form-inline">
                <div class="form-group mb-2 mr-2">
                    <label for="search" class="sr-only">Arama</label>
                    <input type="text" class="form-control" id="search" name="search" placeholder="İsim, e-posta veya telefon" value="<?php echo e(request('search')); ?>">
                </div>
                <div class="form-group mb-2 mr-2">
                    <label for="role" class="sr-only">Rol</label>
                    <select class="form-control" id="role" name="role">
                        <option value="">Tüm Roller</option>
                        <option value="user" <?php echo e(request('role') == 'user' ? 'selected' : ''); ?>>Kullanıcı</option>
                        <option value="admin" <?php echo e(request('role') == 'admin' ? 'selected' : ''); ?>>Yönetici</option>
                    </select>
                </div>
                <button type="submit" class="btn btn-primary mb-2">Ara</button>
                <a href="<?php echo e(route('admin.users.index')); ?>" class="btn btn-secondary mb-2 ml-2">Sıfırla</a>
            </form>
        </div>
    </div>

    <!-- Users Table -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Kullanıcı Listesi</h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="usersTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th style="width: 50px;">ID</th>
                            <th style="width: 70px;">Fotoğraf</th>
                            <th>İsim</th>
                            <th>E-posta</th>
                            <th>Telefon</th>
                            <th>Rol</th>
                            <th>Ödünç Alınan</th>
                            <th>Kayıt Tarihi</th>
                            <th style="width: 150px;">İşlemler</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($user->id); ?></td>
                            <td class="text-center">
                                <?php if($user->profile_photo): ?>
                                <img src="<?php echo e(asset('storage/' . $user->profile_photo)); ?>" alt="<?php echo e($user->name); ?>" class="rounded-circle" width="40" height="40">
                                <?php else: ?>
                                <img src="<?php echo e(asset('img/default-user.png')); ?>" alt="<?php echo e($user->name); ?>" class="rounded-circle" width="40" height="40">
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($user->name); ?> <?php echo e($user->surname); ?></td>
                            <td><?php echo e($user->email); ?></td>
                            <td><?php echo e($user->phone ?: '-'); ?></td>
                            <td>
                                <?php if($user->role == 'admin'): ?>
                                <span class="badge badge-primary">Yönetici</span>
                                <?php else: ?>
                                <span class="badge badge-secondary">Kullanıcı</span>
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($user->borrowings_count ?? 0); ?></td>
                            <td><?php echo e($user->created_at->format('d.m.Y')); ?></td>
                            <td>
                                <div class="d-flex">
                                    <a href="<?php echo e(route('admin.users.show', $user->id)); ?>" class="btn btn-info btn-sm me-1">
                                        <i class="fas fa-eye"></i>
                                    </a>
                                    <a href="<?php echo e(route('admin.users.edit', $user->id)); ?>" class="btn btn-primary btn-sm me-1">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <button type="button" class="btn btn-danger btn-sm" data-bs-toggle="modal" data-bs-target="#deleteModal<?php echo e($user->id); ?>">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </div>
                                
                                <!-- Delete Modal -->
                                <div class="modal fade" id="deleteModal<?php echo e($user->id); ?>" tabindex="-1" role="dialog" aria-labelledby="deleteModalLabel<?php echo e($user->id); ?>" aria-hidden="true">
                                    <div class="modal-dialog" role="document">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="deleteModalLabel<?php echo e($user->id); ?>">Kullanıcıyı Sil</h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">
                                                <p><?php echo e($user->name); ?> <?php echo e($user->surname); ?> isimli kullanıcıyı silmek istediğinize emin misiniz?</p>
                                                <p class="text-danger">Bu işlem geri alınamaz ve kullanıcının tüm verileri silinecektir.</p>
                                                
                                                <?php if($user->borrowings_count > 0): ?>
                                                <div class="alert alert-warning">
                                                    Bu kullanıcının <?php echo e($user->borrowings_count); ?> adet ödünç alma işlemi var!
                                                </div>
                                                <?php endif; ?>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">İptal</button>
                                                <form action="<?php echo e(route('admin.users.destroy', $user->id)); ?>" method="POST" style="display: inline-block;">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit" class="btn btn-danger">Kullanıcıyı Sil</button>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="9" class="text-center">Kayıtlı kullanıcı bulunamadı.</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            
            <!-- Pagination -->
            <div class="d-flex justify-content-center mt-4">
                <?php echo e($users->appends(request()->query())->links()); ?>

            </div>
            
            <!-- Users Count -->
            <div class="mt-3">
                <p class="text-muted">
                    Toplam <?php echo e($users->total()); ?> kullanıcıdan <?php echo e($users->firstItem() ?? 0); ?>-<?php echo e($users->lastItem() ?? 0); ?> arası gösteriliyor.
                </p>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    $(document).ready(function() {
        // Toggle visibility of delete confirmation modals
        $('.delete-user-btn').on('click', function() {
            var userId = $(this).data('user-id');
            $('#deleteModal' + userId).modal('show');
        });
    });
</script>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\irmak\Desktop\KutuphaneOtomasyon\resources\views/admin/users/index.blade.php ENDPATH**/ ?>