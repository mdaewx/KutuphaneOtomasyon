<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('books', function (Blueprint $table) {
            // Slug alanını ekle
            if (!Schema::hasColumn('books', 'slug')) {
                $table->string('slug')->nullable()->after('title');
            }
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('books', function (Blueprint $table) {
            // Slug alanını kaldır
            if (Schema::hasColumn('books', 'slug')) {
                $table->dropColumn('slug');
            }
        });
    }
};
